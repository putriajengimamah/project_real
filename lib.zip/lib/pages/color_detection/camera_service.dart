import 'package:camera/camera.dart';
import 'dart:async';
import 'dart:typed_data';
import 'color_utils.dart';
import 'package:flutter/material.dart';


typedef ColorCallback = void Function(String colorName);

class CameraService {
  late CameraController _controller;
  late List<CameraDescription> _cameras;
  final ColorCallback onColorDetected;
  Timer? _timer;

  CameraService({required this.onColorDetected});

  Future<void> initCamera() async {
    _cameras = await availableCameras();
    _controller = CameraController(
      _cameras.first,
      ResolutionPreset.low,
      enableAudio: false,
    );
    await _controller.initialize();
    _controller.startImageStream(_processCameraImage);
  }

  void _processCameraImage(CameraImage image) {
    if (_timer?.isActive ?? false) return;
    _timer = Timer(const Duration(seconds: 1), () {}); // 1 detik delay

    final bytes = image.planes[0].bytes;
    final width = image.width;
    final height = image.height;
    final centerX = width ~/ 2;
    final centerY = height ~/ 2;
    final pixelIndex = centerY * width + centerX;

    if (pixelIndex < bytes.length - 3) {
      final r = bytes[pixelIndex];
      final g = bytes[pixelIndex + 1];
      final b = bytes[pixelIndex + 2];
      final colorName = getColorNameFromRGB(r, g, b);
      onColorDetected(colorName);
    }
  }

  Widget cameraPreviewWidget() => _controller.value.isInitialized
      ? CameraPreview(_controller)
      : const Center(child: CircularProgressIndicator());

  void dispose() {
    _controller.dispose();
    _timer?.cancel();
  }
}
